# 오늘의 운세 Android 앱 프로젝트

## 포함 기능
- 검정/금색 테마 모바일 앱
- 이름, 성별, 생년월일 입력 및 기기 내 저장
- 종합운, 연애운, 금전운, 직장운
- 날짜 및 프로필에 따라 달라지는 예시 운세 콘텐츠
- 운세 저장 및 공유
- 오프라인 실행 가능한 WebView 앱

## 스마트폰만으로 GitHub Actions에서 APK 만들기
1. 이 ZIP 파일을 스마트폰에 다운로드합니다.
2. GitHub에서 새 Public 또는 Private 저장소를 만듭니다.
3. 저장소 루트에 이 ZIP 파일을 `oneul_fortune_android_project.zip` 이름으로 업로드합니다.
4. 저장소에서 Add file > Create new file을 선택합니다.
5. 파일 이름을 `.github/workflows/build-apk.yml`로 입력합니다.
6. 이 ZIP 안의 `.github/workflows/build-apk.yml` 내용을 복사해 붙여넣고 Commit changes 합니다.
7. Actions 탭 > Build 오늘의 운세 APK > Run workflow를 누릅니다.
8. 실행이 완료되면 해당 실행 상세 화면 아래 Artifacts에서 `oneul-fortune-debug-apk`를 다운로드합니다.
9. ZIP 압축을 풀고 `app-debug.apk`를 눌러 설치합니다.

## 주의
- 이 프로젝트 ZIP을 저장소에 올릴 때 파일 이름을 반드시 `oneul_fortune_android_project.zip`으로 맞춰 주세요.
- GitHub Actions는 Android SDK와 Gradle을 클라우드에서 설치해 APK를 빌드합니다.
- APK는 디버그용 설치 파일입니다. Google Play 배포용 서명 APK/AAB는 별도 서명 설정이 필요합니다.
- 운세 콘텐츠는 앱 안에 포함된 로컬 예시 데이터이며 실제 AI API나 서버와 연결되어 있지 않습니다.
- 프로필과 저장한 운세는 앱이 설치된 기기의 로컬 저장소에 보관됩니다.
